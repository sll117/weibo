create definer = root@localhost trigger tr_delete_blog
    before delete
    on myblog
    for each row
    DELETE
                 FROM comment
                 WHERE comment_weibo_id = OLD.weibo_id;

